package com.example.test.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
public class UrlConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/img/**")
                .addResourceLocations("file:test/src/main/resources/img/");
        registry.addResourceHandler("/video/**")
                .addResourceLocations("file:test/src/main/resources/video/");//规定路径映射
        registry.addResourceHandler("/static/**")
                .addResourceLocations("file:test/src/main/resources/static/");//规定路径映射
    }
}


