package com.example.test.controller;

import lombok.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class UploadController {

    private static final String videoUploadDir = "C:\\video\\"; // 视频上传目录

    @RequestMapping("/upload")
    public String uploadVideo(@RequestParam("videoFile") MultipartFile file, Model model) {
        try {
            // 将文件保存到服务器上的指定目录中
            String fileName = StringUtils.cleanPath(file.getOriginalFilename());
            Path path = Paths.get(videoUploadDir + fileName);
            Files.write(path, file.getBytes());

            System.out.println(fileName);
            String message = "视频上传成功：" + fileName;
            model.addAttribute("message", message);
        } catch (Exception e) {
            String message = "视频上传失败：" + e.getMessage();
            model.addAttribute("message", message);
        }
        return "index"; // 返回结果页面
    }
}
