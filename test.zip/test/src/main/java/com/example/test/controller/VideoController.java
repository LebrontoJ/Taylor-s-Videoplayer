package com.example.test.controller;

import com.example.test.pojo.Transbody;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import com.example.test.mapper.VideoMapper;
import com.example.test.pojo.UserLogin;

import java.util.*;

import com.example.test.pojo.Video;
import com.example.test.services.UserLoginServicesI;
import com.example.test.services.VideoServicesI;
import com.example.test.services.VideoServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class VideoController {

    @Autowired
    VideoServicesI videoServicesI;
    @Autowired
    UserLoginServicesI userLoginServicesI;
    Long userID;
    String username;
    String urlh;
    @RequestMapping("/index")
    public String index (Model model, Video video, @RequestParam String userss){//通过参数方式传递用户id
        userID=Long.parseLong(userss);
        int count=1;
        long val=0;
        username= userLoginServicesI.queryById(userID).getUsername();
        model.addAttribute("data","欢迎，用户"+username);
        List<Video> videos=videoServicesI.queryAll();
        System.out.println(videos);
        List<Transbody>response = new ArrayList<>();//排除管理员后的用户列表
        for (Video video1 : videos) {
            if(video1.getUserid().equals(userID))//这里String与Long比较不会报错，注意检查
            {
                Transbody temp=new Transbody();
                temp.setUrl(video1.url);
                val=(long)count;
                temp.setEpisode(Long.toString(val));
                response.add(temp);
                count+=1;
            }
        }
        model.addAttribute("videos",response);
        return "index";
    }

    @RequestMapping("/backend")
    public String backend (Model model, Video video,@RequestParam String userss){//通过参数方式传递用户id
        userID=Long.parseLong(userss);
        username= userLoginServicesI.queryById(userID).getUsername();
        model.addAttribute("data","管理员"+username);
        System.out.println("管理员id"+userID);
        return "backend";
    }

    @RequestMapping("/videohandle")
    public String videoHandle(Model model) {
        List<Video> video1=videoServicesI.queryAll();
        Comparator<Video> VideoidComparator = new Comparator<Video>() {
            @Override
            public int compare(Video v1, Video v2) {
                return (int)(v1.getUserid()-v2.getUserid());
            }
        };//实现一个比较函数

        Collections.sort(video1, VideoidComparator);//视频按userid升序排列
        for(Video vi:video1)
            vi.setUrl(vi.getUrl().trim().replace("\"", ""));
        model.addAttribute("videos", video1);
        return "videohandle";
    }
     @RequestMapping("/userhandle")
     public String userHandle(Model model) {
         List<UserLogin> users=userLoginServicesI.queryAll();
         List<UserLogin>response = new ArrayList<>();//排除管理员后的用户列表
         for (UserLogin user : users) {
//             if(user.identity.equals("V"))
                 response.add(user);
         }
         model.addAttribute("users",response);
         return "userhandle";
     }
    @RequestMapping("/backhome")
    public String backhome(Model model) {
        System.out.println(username);
        return "backend";
    }
    @RequestMapping("/edit1/{id}")//编辑视频信息
    public String toEdit1(@PathVariable Long id, Model model){
        model.addAttribute("video",videoServicesI.queryByVid(id));
        return "editVideo";
    }
    @RequestMapping("/edit1")
    public String edit1(Video video, RedirectAttributes attributes){
        boolean b = videoServicesI.updateVideo(video);
        if (b){
            attributes.addFlashAttribute("message","更新视频信息成功");
            return "redirect:/videohandle";  //重定向到/页面
        }else {
            attributes.addFlashAttribute("message","更新视频信息失败");
            return "redirect:/videohandle";  //重定向到/页面
        }
    }
    @RequestMapping("/delete1/{id}")  //网页路径
    public String delete(@PathVariable("id") Long id, RedirectAttributes  attributes){
        boolean b = videoServicesI.deleteByVid(id);
        if (b){
            attributes.addFlashAttribute("message","删除视频成功");
            return "redirect:/videohandle";  //重定向到/页面
        }else {
            attributes.addFlashAttribute("message","删除视频失败");
            return "redirect:/videohandle";  //重定向到/页面
        }
    }
}

