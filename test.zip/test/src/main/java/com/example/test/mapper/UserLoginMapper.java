package com.example.test.mapper;

import com.example.test.pojo.UserLogin;
import com.example.test.pojo.Video;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface UserLoginMapper {
    //查询
    public List<UserLogin> queryAll();
    //添加数据
    public int add(UserLogin userLogin);
    //根据用户名查询数据
    public UserLogin queryByName(String username);
    public UserLogin queryById(Long userid);
    //修改用户
    public int updateUser(UserLogin user);
    //根据用户id删除用户
    public int deleteUserById(Long userid);


}

