package com.example.test.mapper;

import com.example.test.pojo.UserLogin;
import com.example.test.pojo.Video;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface VideoMapper {
    //查询
    public List<Video> queryAll();

    //添加数据
    public int add(Video video);
    //根据用户名查询数据
    public Video queryByVid(Long videoid);
    public Video queryByUid(Long userid);
    //删除数据
    public int deleteByVid(Long videoid);
    public int updateVideo(Video video);
}

