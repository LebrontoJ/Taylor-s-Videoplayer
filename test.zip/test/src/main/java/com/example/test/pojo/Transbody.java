package com.example.test.pojo;

import lombok.Data;

@Data
public class Transbody{//用于客户端传送数据
    public String url;
    public String episode;
}