package com.example.test.pojo;

import lombok.Data;

@Data
public class UserLogin {
    public String username;
    public String password;
    public String identity;
    public Long userid;
}
