package com.example.test.pojo;

import lombok.Data;
@Data
public class Video {
    public String url;
    public Long userid;
    public Long videoid;
}


