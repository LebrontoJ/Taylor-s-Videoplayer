package com.example.test.pojo;

public class VideoData {
    private Long id;
    private String url;
    private Long videoid;

    public Long getId() {
        return videoid;
    }

    public void setId(Long id) {
        this.videoid = videoid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
