package com.example.test.services;

import com.example.test.pojo.UserLogin;
import com.example.test.pojo.Video;

import java.util.List;

public interface UserLoginServicesI {
    //查询
    public List<UserLogin> queryAll();
    //添加数据
    public int add(UserLogin userLogin);
    //根据用户名查询数据
    public UserLogin queryByName(String username);
    public UserLogin queryById(Long userid);
    //修改用户
    public boolean updateUser(UserLogin user);
    //根据用户id删除用户
    public boolean deleteUserById(Long userid); //希望得到的结果是是否被删除，故是boolean类型


}
