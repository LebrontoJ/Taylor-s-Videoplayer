package com.example.test.services;

import com.example.test.mapper.UserLoginMapper;
import com.example.test.pojo.UserLogin;
import com.example.test.pojo.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserLoginServicesImpl implements UserLoginServicesI {

    @Autowired
    UserLoginMapper userLoginMapper;
    @Override
    public List<UserLogin> queryAll() {
        return userLoginMapper.queryAll();
    }

    @Override
    public int add(UserLogin userLogin) {
        return userLoginMapper.add(userLogin);
    }

    @Override
    public UserLogin queryByName(String username) {
        return userLoginMapper.queryByName(username);
    }
    @Override
    public UserLogin queryById(Long userid) {
        return userLoginMapper.queryById(userid);
    }

    @Override
    public boolean updateUser(UserLogin user) {
        int i = userLoginMapper.updateUser(user);
        if (i > 0){
            return true;
        }else {
            return false;
        }
    }
    @Override
    public boolean deleteUserById(Long userid) {
        int i = userLoginMapper.deleteUserById(userid);
        if (i > 0){
            return true; //删除成功
        }else {
            return false;
        }
    }

}
