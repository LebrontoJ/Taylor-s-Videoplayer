package com.example.test.services;

import com.example.test.pojo.Video;

import java.util.List;

public interface VideoServicesI {
    //查询
    public List<Video> queryAll();
    //添加数据
    public int add(Video video);
    //根据用户名查询数据
    public Video queryByVid(Long videoid);
    public Video queryByUid(Long userid);
    public boolean deleteByVid(Long videoid);
    public boolean updateVideo(Video video);

}
