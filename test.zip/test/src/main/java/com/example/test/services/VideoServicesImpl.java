package com.example.test.services;

import com.example.test.mapper.VideoMapper;
import com.example.test.pojo.UserLogin;
import com.example.test.pojo.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideoServicesImpl implements VideoServicesI {

    @Autowired
    VideoMapper videoMapper;
    @Override
    public List<Video> queryAll() {
        return videoMapper.queryAll();
    }

    @Override
    public int add(Video video) {
        return videoMapper.add(video);
    }

    @Override
    public Video queryByVid(Long videoid) {
        return videoMapper.queryByVid(videoid);
    }
    @Override
    public Video queryByUid(Long userid) {
        return videoMapper.queryByUid(userid);
    }
    @Override
    public boolean deleteByVid(Long videoid){
        int i=videoMapper.deleteByVid(videoid);
        if(i>0)
            return true;
        else
            return false;
    }
    @Override
    public boolean updateVideo(Video video) {
        int i = videoMapper.updateVideo(video);
        if (i > 0){
            return true;
        }else {
            return false;
        }
    }
}
