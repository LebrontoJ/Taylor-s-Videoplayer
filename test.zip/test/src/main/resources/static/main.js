window.onload = function(){//加载网页时执行以下函数

	var video = document.getElementById("video");
	var lis = document.getElementsByTagName("li");
	var vLen = lis.length; // 播放列表的长度
	var url = [];
	var ctrl = document.getElementById("playList-hidden");
	var ctrl_show = document.getElementById('playList-show1');
	var aside = document.getElementById("playList");//播放列表边栏
	var curr = 0; // 当前播放的视频
	var fileInput = document.getElementById('fileInput');//用于导入文件夹下的文件
	var videolist=document.getElementById("List");
	var lis1=videolist.getElementsByTagName("li");


	fileInput.addEventListener('change', function(event) {
            var files = event.target.files;

			if(files.length==0)
			{
				console.log("No files chosen this time");
				return;
			}//处理点了按钮但取消的情况
			var num=0;//记录合法的文件数
			for(i=0;i<files.length;i++)
			{
				var len=files[i].name.length;
				if(len>3)
				{
					var judge=files[i].name;
					if(judge.substring(len-3)=="mp4")
					{
						if(num+1>lis.length)//动态增加元素
						{
							var len=files[i].name.length;
							var node=document.createElement("li");
							var attr=document.createAttribute("title");
							var attr1=document.createAttribute("value");
							attr.nodeValue="xx";
							attr1.nodeValue="xx";
							node.attributes.setNamedItem(attr);
							node.attributes.setNamedItem(attr1);
							videolist.appendChild(node);
						}
						lis1[num].setAttribute("title",judge.substring(0,len-4));
						lis1[num].innerHTML = lis1[num].getAttribute("title");//由title属性来更新列表中的名称
						lis1[num].setAttribute("value",files[i].webkitRelativePath);
						num++;
					}
				}
			}
			for(j=i;j<lis.length;j++)
				videolist.removeChild(lis1[j]);//清除多的列表元素
			window.onload();
				//添加元素后，若不调用window.onload()更新一遍，那么新添的视频无法播放，这一步主要是更新列表的长度
        });

	for(var i=0;i<lis.length;i++){
		url[i] = lis[i].getAttribute("value");
	}

	//绑定单击事件
	for(var i=0;i<lis.length;i++){
			lis[i].onclick = function(){
				for(var j=0;j<lis.length;j++){
					if(lis[j] == this){
						video.setAttribute("src",this.getAttribute("value"));
						video.setAttribute('autoplay','autoplay');
						this.innerHTML = this.innerHTML;
						this.className = "select";
						curr = j+1;
					}else{
						lis[j].innerHTML = lis[j].getAttribute("title");//由title属性来更新列表中的名称
						lis[j].className = "";
					}
				}
			}
		}
	console.log(window);
	//收起播放列表
	ctrl.onclick = function(){

		aside.style.transition = "1s";
		aside.style.transform = "translateX(-10vw)";
		setTimeout(function(){
			aside.style.display = "none";
			ctrl_show.style.visibility= 'visible';
		},"1000");

	}

	//展开播放列表
	ctrl_show.onclick = function(){
		aside.style.display = "block";
		ctrl_show.style.visibility= 'hidden';
		setTimeout(function(){
			aside.style.transform = "translateX(0vw)";
		},"0");

	}

	// //设定初始视频的url值
	// video.setAttribute('src',url[0]);
	// lis[0].innerHTML = lis[0].innerHTML;
	// lis[0].className = "select";


	//视频播放控制函数
	video.addEventListener('ended', play1);
	//play();
	function play1() {
	   video.src = url[curr];
	   video.load(); // 如果短的话，可以加载完成之后再播放，监听 canplaythrough 事件即可
	   video.play();

	   for(var j=0;j<lis.length;j++){
			if(j == curr){
				video.setAttribute("src",lis[j].getAttribute("value"));
				video.setAttribute('autoplay','autoplay');
				lis[j].innerHTML = lis[j].innerHTML;
				lis[j].className = "select";
			}else{
				lis[j].innerHTML = lis[j].getAttribute("title");
				lis[j].className = "";
			}
		}
	   curr++;
	   if (curr >= vLen) curr = 0; // 播放完了，重新播放
	}

}
